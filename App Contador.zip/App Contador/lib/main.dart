// Importa o pacote principal do Flutter para criar interfaces visuais
import 'package:flutter/material.dart';

// Função principal do app (ponto de entrada)
void main() {
  // Inicia o aplicativo e carrega o widget MyApp
  runApp(const MyApp());
}

// Widget principal do aplicativo
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // MaterialApp define configurações globais do app
    return const MaterialApp(
      // Remove a faixa "DEBUG" do canto da tela
      debugShowCheckedModeBanner: false,

      // Define a tela inicial do aplicativo
      home: HomePage(),
    );
  }
}

// Widget da tela principal (precisa ser Stateful para mudar o contador)
class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

// Classe que controla o estado da tela
class _HomePageState extends State<HomePage> {
  // Variável que armazena o número de pessoas no local
  int count = 0;

  // Função chamada quando alguém sai
  void decrement() {
    setState(() {
      // Garante que o número nunca fique abaixo de zero
      if (count > 0) {
        count--;
      }
    });
  }

  // Função chamada quando alguém entra
  void increment() {
    setState(() {
      count++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Container usado para colocar a imagem de fundo
      body: Container(
        width: double.infinity,
        height: double.infinity,

        // Define a imagem de fundo da tela
        decoration: const BoxDecoration(
          image: DecorationImage(
            image: AssetImage('assets/images/restaurante.jpg'),
            fit: BoxFit.cover,
          ),
        ),

        // Organiza os elementos verticalmente
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Texto principal
            const Text(
              'Pode entrar!',
              style: TextStyle(
                fontSize: 30,
                color: Colors.white,
                fontWeight: FontWeight.w700,
              ),
            ),

            // Espaço entre o texto e o número
            const SizedBox(height: 24),

            // Mostra o valor atual do contador
            Text(
              '$count',
              style: const TextStyle(
                fontSize: 100,
                color: Colors.white,
              ),
            ),

            // Espaço entre o número e os botões
            const SizedBox(height: 32),

            // Linha de botões
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Botão "Saiu"
                TextButton(
                  onPressed: decrement,
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.white,
                    fixedSize: const Size(100, 100),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Saiu',
                    style: TextStyle(fontSize: 16),
                  ),
                ),

                // Espaço entre os botões
                const SizedBox(width: 32),

                // Botão "Entrou"
                TextButton(
                  onPressed: increment,
                  style: TextButton.styleFrom(
                    backgroundColor: Colors.white,
                    fixedSize: const Size(100, 100),
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: const Text(
                    'Entrou',
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
